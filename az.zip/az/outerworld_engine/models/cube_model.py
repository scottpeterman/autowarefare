"""
Wireframe model converted from cube.an8

Source mesh : 8 points, 6 faces
Edges       : 12 unique (deduped from 24 face perimeter walks)
Bounds      : X[-18.59, 18.59]  Y[0.00, 39.28]  Z[-18.59, 18.59]
Y shift     : +19.6410 (ground-aligned: lowest vertex placed at y=0)

Coordinate convention: +Y = up (matches Anim8or source and the
Castle of Bane / Battlezone entity-local-space convention).
No axis flip is applied. The original Heminger PHP exporter
negated all three axes; we do not.
"""

CUBE_MODEL = {
    "lines": [
        ((-18.585, 0, -18.585), (18.585, 0, -18.585)),
        ((18.585, 0, -18.585), (18.585, 39.282, -18.585)),
        ((18.585, 39.282, -18.585), (-18.585, 39.282, -18.585)),
        ((-18.585, 39.282, -18.585), (-18.585, 0, -18.585)),
        ((-18.585, 0, 18.585), (-18.585, 39.282, 18.585)),
        ((-18.585, 39.282, 18.585), (18.585, 39.282, 18.585)),
        ((18.585, 39.282, 18.585), (18.585, 0, 18.585)),
        ((18.585, 0, 18.585), (-18.585, 0, 18.585)),
        ((-18.585, 39.282, -18.585), (-18.585, 39.282, 18.585)),
        ((-18.585, 0, 18.585), (-18.585, 0, -18.585)),
        ((18.585, 0, -18.585), (18.585, 0, 18.585)),
        ((18.585, 39.282, 18.585), (18.585, 39.282, -18.585)),
    ],
    "scale": 1.0,
    "bob_speed": 0.0,
    "bob_amount": 0.0,
}
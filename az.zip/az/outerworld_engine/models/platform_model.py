"""
Wireframe model converted from platform.an8

Source mesh : 8 points, 6 faces
Edges       : 12 unique (deduped from 24 face perimeter walks)
Bounds      : X[-10.13, 10.13]  Y[0.00, 4.99]  Z[-10.13, 10.13]
Y shift     : +2.4963 (ground-aligned: lowest vertex placed at y=0)

Coordinate convention: +Y = up (matches Anim8or source and the
Castle of Bane / Battlezone entity-local-space convention).
No axis flip is applied. The original Heminger PHP exporter
negated all three axes; we do not.
"""

PLATFORM_MODEL = {
    "lines": [
        ((-10.132, 0, -10.132), (10.132, 0, -10.132)),
        ((10.132, 0, -10.132), (10.132, 4.9926, -10.132)),
        ((10.132, 4.9926, -10.132), (-10.132, 4.9926, -10.132)),
        ((-10.132, 4.9926, -10.132), (-10.132, 0, -10.132)),
        ((-10.132, 0, 10.132), (-10.132, 4.9926, 10.132)),
        ((-10.132, 4.9926, 10.132), (10.132, 4.9926, 10.132)),
        ((10.132, 4.9926, 10.132), (10.132, 0, 10.132)),
        ((10.132, 0, 10.132), (-10.132, 0, 10.132)),
        ((-10.132, 4.9926, -10.132), (-10.132, 4.9926, 10.132)),
        ((-10.132, 0, 10.132), (-10.132, 0, -10.132)),
        ((10.132, 0, -10.132), (10.132, 0, 10.132)),
        ((10.132, 4.9926, 10.132), (10.132, 4.9926, -10.132)),
    ],
    "scale": 1.0,
    "bob_speed": 0.0,
    "bob_amount": 0.0,
}
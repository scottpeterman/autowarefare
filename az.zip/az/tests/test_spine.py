"""
tests/test_spine.py — headless acceptance test for the integration spine.

Runs with no GL and no Qt. Covers, against the REAL battlefield engine:
  A. the outdoor world is drivable and stays in bounds,
  B. the one-shell-at-a-time fire rule holds,
  C. a player bullet killing an enemy routes score through shell PlayerState,
  D. the portal hands off both ways; health taken indoors and a cleared flag
     both persist across the seam, and the outdoor pose is restored on return.

Run:  python -m az.tests.test_spine   (or: pytest az/tests/test_spine.py)
"""

from __future__ import annotations

from az.outerworld_engine.bullet import Bullet
from az.outerworld_engine.tank import Tank
from az.outerworld_engine.models.cube_model import CUBE_MODEL
from az.outerworld_engine.models.tank_model import TANK_MODEL

from az.indoor.world import IndoorWorld
from az.outdoor.world import OutdoorWorld, TANK_SCORE, TOWER_ID
from az.shell.mode import NO_INPUT, InputState, Transition
from az.shell.player_state import PlayerState
from az.shell.portal import Portal

DT = 1.0 / 60.0
FORWARD = InputState(forward=True)
FIRE = InputState(fire=True)
ACTION = InputState(action=True)


def _fresh():
    state = PlayerState()
    worlds = {"outdoor": OutdoorWorld(), "indoor": IndoorWorld()}
    portal = Portal(worlds)
    worlds["outdoor"].on_enter(state, {})
    return state, worlds, portal


def test_a_drivable() -> None:
    state, worlds, _ = _fresh()
    ow = worlds["outdoor"]
    z0 = ow.camera.z
    for _ in range(120):
        ow.update(DT, FORWARD, state)
    assert ow.camera.z < z0, "holding forward should move along -Z"
    assert ow.battlefield.in_bounds(ow.camera.x, ow.camera.z), "must stay in bounds"


def test_b_one_shell_rule() -> None:
    state, worlds, _ = _fresh()
    ow = worlds["outdoor"]
    ow.update(DT, FIRE, state)
    assert len(ow.battlefield.bullets) == 1, "fire should spawn exactly one shell"
    assert not ow._can_fire(), "second shell blocked while first is in flight"
    ow.update(DT, FIRE, state)
    assert len(ow.battlefield.bullets) == 1, "no second shell until the first clears"


def test_c_kill_routes_score_to_playerstate() -> None:
    state, worlds, _ = _fresh()
    ow = worlds["outdoor"]
    ow.battlefield.tanks.clear()
    ow.battlefield.bullets.clear()
    cx, cz = ow.camera.x, ow.camera.z
    ow.battlefield.add_tank(Tank(model=TANK_MODEL, x=cx, z=cz - 100.0, ai_seed=7))
    ow.battlefield.add_bullet(Bullet(model=CUBE_MODEL, x=cx, z=cz - 100.0,
                                     vx=0.0, vz=0.0, range_remaining=100.0,
                                     bounding_radius=1.0, owner="player"))
    score0 = state.score
    ow._sim_tick(NO_INPUT, state)
    assert len(ow.battlefield.tanks) == 0, "player bullet should kill the tank"
    assert state.score == score0 + TANK_SCORE, "kill must score through PlayerState"


def test_d_portal_roundtrip_persists_state() -> None:
    state, worlds, portal = _fresh()
    ow = worlds["outdoor"]
    # park the auto at the tower lobby (driving the full ~1km is a separate concern)
    ow.camera.x, ow.camera.z = ow._lobby.x, ow._lobby.z
    saved = ow.save_pose()

    t = ow.update(DT, ACTION, state)
    assert t is not None and t.target == "indoor"
    active = portal.transit(ow, t, state)
    assert active.name == "indoor"

    hp0 = state.health
    t = None
    for _ in range(600):
        t = active.update(DT, FORWARD, state)
        if t is not None:
            break
        if active._in_zone(active.exit_x, active.exit_z, 45.0):
            t = active.update(DT, ACTION, state)
            break
    assert state.health < hp0, "indoor hazard should spend HP"
    assert t is not None and t.target == "outdoor"

    active = portal.transit(active, t, state)
    assert active.name == "outdoor"
    assert state.has_cleared(TOWER_ID)
    assert abs(state.health - 75.0) < 1e-6, "HP must persist across the seam"
    assert abs(active.camera.x - saved[0]) < 1e-6 and abs(active.camera.z - saved[1]) < 1e-6


def _run_all() -> None:
    for fn in (test_a_drivable, test_b_one_shell_rule,
               test_c_kill_routes_score_to_playerstate,
               test_d_portal_roundtrip_persists_state):
        fn()
        print(f"  PASS  {fn.__name__}")


if __name__ == "__main__":
    _run_all()
    print("M1 increment-1 spine PASS: real BZ engine wrapped; drive + fire + "
          "kill->score(PlayerState) + portal round-trip persisting HP/cleared/pose")
